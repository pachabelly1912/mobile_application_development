import React, { Component } from 'react';
import {
    View
} from 'react-native'
import HeaderBar from '../../commons/headerBar';
import DetailContent from './content';

export default class HomeContainer extends Component {

    static navigationOptions = (navigation) => {
        return {
            header: <HeaderBar title={'Detail'} renderLeftButton={true} isHomeScreen={false} renderRightButton={false} />
        }
    }
    render(){
        return <DetailContent />
    }
    
}