import React, { Component } from 'react';
import {
    View,
    Image,
    Text,
} from 'react-native';
import { StockLine } from 'react-native-pathjs-charts'
import styles from './styles';
export default class DetailContent extends Component {

    render() {
        let data = [
            [{
                "x": 0,
                "y": 100
            }, {
                "x": 1,
                "y": 100
            }, {
                "x": 2,
                "y": 40
            }, {
                "x": 3,
                "y": 100
            }, {
                "x": 4,
                "y": 50
            }, {
                "x": 5,
                "y": 20
            }, {
                "x": 6,
                "y": 40
            }, {
                "x": 7,
                "y": 55
            }, {
                "x": 8,
                "y": 66
            }, {
                "x": 9,
                "y": 77
            }, {
                "x": 10,
                "y": 88
            }, {
                "x": 11,
                "y": 90
            }, {
                "x": 12,
                "y": 11
            }, {
                "x": 13,
                "y": 33
            }, {
                "x": 14,
                "y": 55
            }, {
                "x": 15,
                "y": 66
            }, {
                "x": 16,
                "y": 30
            }, {
                "x": 17,
                "y": 20
            }, {
                "x": 18,
                "y": 22
            }]
        ]
        let options = {
            min: 0,
            max: 100,
            width: 300,
            height: 80,
            color: '#2980B9',
            margin: {
                top: 10,
                left: 35,
                bottom: 30,
                right: 10
            },
            animate: {
                type: 'delayed',
                duration: 200
            },
            axisX: {
                showAxis: true,
                showLines: false,
                showLabels: false,
                showTicks: false,
                zeroAxis: false,
                orient: 'bottom',
                tickValues: [],
                label: {
                    fontFamily: 'OCRAStd',
                    fontSize: 8,
                    fontWeight: true,
                    fill: '#ffffff'
                }
            },
            axisY: {
                showAxis: true,
                showLines: true,
                showLabels: true,
                showTicks: true,
                zeroAxis: false,
                orient: 'left',
                tickValues: [],
                label: {
                    fontFamily: 'OCRAStd',
                    fontSize: 8,
                    fontWeight: true,
                    fill: '#ffffff'
                }
            }
        }

        return (

            <View style={styles.container}>
                <View style={styles.snackBar} />
                <View style={{ flex: 1 }}>
                    <Text style={{
                        backgroundColor: '#051429',
                        paddingTop: 10,
                        paddingLeft: 10,
                        height: 30,
                        color: '#42C84B',
                        fontFamily: 'OCRAStd'
                    }}>GPu asjhlasd</Text>
                    <View style={{ flexDirection: 'row', flex: 1 / 4, paddingTop: 10 }}>
                        <View style={{ width: 70, justifyContent: 'center' }} >
                            <Image style={{ alignSelf: 'center' }} source={require('../../assets/images/ram.png')} />
                            <Text style={{color: 'white', alignSelf: 'center', height: 30,fontFamily: 'OCRAStd', marginTop: 10}}>40%</Text>
                        </View>
                        <View style={{ paddingTop: 20 }}>
                            <StockLine data={data} options={options} xKey='x' yKey='y' />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', flex: 1 / 4, paddingTop: 10 }}>
                        <View style={{ width: 70, justifyContent: 'center' }} >
                            <Image style={{ alignSelf: 'center' }} source={require('../../assets/images/fan.png')} />
                            <Text style={{color: 'white', alignSelf: 'center', height: 30,fontFamily: 'OCRAStd', marginTop: 10}}>20%</Text>
                        </View>
                        <View style={{ paddingTop: 20 }}>
                            <StockLine data={data} options={options} xKey='x' yKey='y' />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', flex: 1 / 4, paddingTop: 10 }}>
                        <View style={{ width: 70, justifyContent: 'center' }} >
                            <Image style={{ alignSelf: 'center' }} source={require('../../assets/images/power.png')} />
                            <Text style={{color: 'white', alignSelf: 'center', height: 30,fontFamily: 'OCRAStd', marginTop: 10}}>30%</Text>
                        </View>
                        <View style={{ paddingTop: 20 }}>
                            <StockLine data={data} options={options} xKey='x' yKey='y' />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', flex: 1 / 4, paddingTop: 10 }}>
                        <View style={{ width: 70, justifyContent: 'center' }} >
                            <Image style={{ alignSelf: 'center' }} source={require('../../assets/images/temp.png')} />
                            <Text style={{color: 'white', alignSelf: 'center', height: 30,fontFamily: 'OCRAStd', marginTop: 10}}>10%</Text>
                        </View>
                        <View style={{ paddingTop: 20 }}>
                            <StockLine data={data} options={options} xKey='x' yKey='y' />
                        </View>
                    </View>

                </ View>

            </View>
        )
    }

}