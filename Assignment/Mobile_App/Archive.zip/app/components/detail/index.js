import Detail from './container';
export default Detail;