import { StyleSheet } from 'react-native';

export default StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'black'
    },
    snackBar: { 
        height: 6, 
        backgroundColor: '#9B9B9B' 
    }
})