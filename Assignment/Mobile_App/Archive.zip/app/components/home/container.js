import React, { Component } from 'react';
import {
    View,
    Text,

} from 'react-native';
import HeaderBar from '../../commons/headerBar';
import HomeContent from './content';
import testData from './testData';

export default class HomeContainer extends Component {

    static navigationOptions = (navigation) => {
        return {
            header: <HeaderBar title={'Miner Tracker'} renderLeftButton={true} isHomeScreen={true} renderRightButton={true} />
        }
    }

    onTapDetail = (computerIndex, gpuIndex) => {
        if (computerIndex === this.state.detailIndex.computerIndex && gpuIndex === this.state.detailIndex.gpuIndex) {
            this.setState({
                detailIndex: {
                    computerIndex: null,
                    gpuIndex: null
                }
            })
        }
        else
            this.setState({
                detailIndex: {
                    computerIndex,
                    gpuIndex
                }
            })
    }

    constructor(props) {
        super(props);
        this.state = {
            listData: testData,
            detailIndex: {
                computerIndex: null,
                gpuIndex: null,
            }
        }
    }


    render() {
        return (
            <HomeContent listData={this.state.listData} detailIndex={this.state.detailIndex} onTapDetail={this.onTapDetail} />
        )
    }
}