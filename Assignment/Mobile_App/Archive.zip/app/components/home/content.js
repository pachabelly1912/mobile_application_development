import React, { Component } from 'react';
import {
    View,
    Text,
    FlatList,
    Image,
    TouchableOpacity

} from 'react-native';
import styles from './styles';
export default class HomeContent extends Component {

    renderItem(item, index) {
        return <View style={{ backgroundColor: '#0B1F3D' }}>
            <View style={styles.headerList}>
                <View style={{ flex: 3 / 4 }}>
                    <Text style={styles.headerText}>{item.Name}</Text>
                </View>
                <View style={{ flex: 1 / 4, flexDirection: 'row', justifyContent: 'space-around' }}>
                    <TouchableOpacity><Image style={styles.detailButton} source={require('../../assets/images/hammer.png')} /></TouchableOpacity>
                    <TouchableOpacity><Image style={styles.detailButton} source={require('../../assets/images/chart.png')} /></TouchableOpacity>
                </View>
            </View>
            <View>
                {item.GPUs.map((gpu, gpuIndex) => {
                    return (
                        <View>
                            {gpuIndex !== 0 && <Image style={styles.seperator} source={require('../../assets/images/seperator.png')} />}
                            <View style={styles.gpuContainer}>
                                <TouchableOpacity style={styles.statusButtonContainer}>
                                    <Image style={styles.statusButton} source={require('../../assets/images/safe-status-button.png')} />
                                </TouchableOpacity>
                                <Text style={styles.gpuNameText}>{gpu.Name}</Text>
                            </View>
                        </View>
                    )
                })}
            </View>
            <View style={{ backgroundColor: 'black', height: 5 }} />
        </View>
    }

    render() {
        console.log(this.props.listData)
        return (
            <View style={styles.container}>
                <View style={styles.snackBar} />
                <FlatList
                    style={{ flex: 1 }}
                    data={this.props.listData}
                    renderItem={({ item, index }) => this.renderItem(item, index)}
                    keyExtractor={(item, index) => { return index }}
                />
            </View>
        )
    }
}