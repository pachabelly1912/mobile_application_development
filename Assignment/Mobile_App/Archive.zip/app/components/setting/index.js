import Setting from './container';
export default Setting