export default {
    SCREEN: {
        HOME: 'HOME',
        DETAIL: 'DETAIl',
        SETTING: 'SETTING'
    }
}