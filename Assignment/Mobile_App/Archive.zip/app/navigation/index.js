import AppNavigation from './stackNavigation';
export default AppNavigation;