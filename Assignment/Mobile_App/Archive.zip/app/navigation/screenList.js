import ENUMS from '../constants/enums';
import Home from '../components/home';
import Detail from '../components/detail';
import Setting from '../components/setting';
export default {
    [ENUMS.SCREEN.SETTING]: {
        screen: Setting
    },
    [ENUMS.SCREEN.DETAIL]: {
        screen: Detail
    },
    [ENUMS.SCREEN.HOME]:{
        screen: Home
    }
    
}