import { StackNavigator } from 'react-navigation';
import screenList from './screenList';

export default StackNavigator(screenList);